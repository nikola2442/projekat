import React from "react";
export const Balans = () => {
    return(
        <div>
            <h4>Vaše stanje</h4>
            <h1 id="balance">0.00 din</h1>
        </div>
    );
}