import React from "react";
export const Transakcija = () => {
    return(
        <div className="transakcija">
            
        </div>
    );
}