import React from "react";
export const Header = () => {
    return(
        <h2>
        Potrošnja novca
        </h2>
    );
}