import React from "react";
export const Prihodi = () => {
    return(
        <div className="prihod">
            <div>
                <h4>Prihodi</h4>
                <p className="novac plus">+0.00 din</p>
            </div>
            <div>
                <h4>Rashodi</h4>
                <p className="novac minus">-0.00 din</p>
            </div>
        </div>
    );
}